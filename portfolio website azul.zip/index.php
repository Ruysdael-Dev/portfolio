<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>responsive personal portfolio website design tutorail</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

    

</head>
<body>
  
   
<!-- header section starts  -->

<header>

    <div class="user">
       <a href="https://www.linkedin.com/in/ruysdael-oliveira-morais-1a9095232"> <img src="images/pic.jpg" alt=""></a>
       <a href="https://www.linkedin.com/in/ruysdael-oliveira-morais-1a9095232"> <h3 class="name">Ruysdael Morais</h3></a>
       <a href="https://www.linkedin.com/in/ruysdael-oliveira-morais-1a9095232"> <p class="post">Desenvolvedor Front End</p></a>
    </div>

    <nav class="navbar">
        <ul>
            <li><a href="#home">home</a></li>
            <li><a href="#about">Sobre</a></li>
            <li><a href="#education">Cursos e certificações</a></li>
            <li><a href="#portfolio">portfolio</a></li>
            <li><a href="#contact">contato</a></li>
            <div id="marker"></div>
        </ul>
    </nav>

</header>

<!-- header section ends -->

<div id="menu" class="fas fa-bars"></div>

<!-- home section starts  -->

<section class="home" id="home">
    <h3>Olá !</h3>
    <h1>Me chamo <span>Ruysdael Oliveira Morais</span></h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio deserunt aspernatur fugiat minus enim ullam repudiandae sint sed magnam tenetur! Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, at.
    </p>
    <a href="#about"><button class="btn">Sobre Mim <i class="fas fa-user"></i></button></a>
</section>

<!-- home section ends -->

<!-- about section starts  -->

<section class="about" id="about">

<h1 class="heading"> <span>Sobre</span> Mim </h1>

<div class="row">

    <div class="info">
        <h3> <span> Nome : </span> Ruysdael Oliveira Morais </h3>
        <h3> <span> Idade : </span> 30 </h3>
        <h3> <span> Formação : </span> Graduando em Analises e Desenvolvimento de Sistemas </h3>
        <h3> <span> Conclusao : </span> Prevista para 1º semestre de 2024 </h3>
        <h3> <span> Qualificações : </span> front end developer </h3>
        <h3> <span> linguagem : </span> Portugues-Brasil </h3>
        <a href="#"><button class="btn"> Baixar Meu Curriculum <i class="fas fa-download"></i> </button></a>
    </div>

    <div class="counter">

        <div class="box">
            <span>2+</span>
            <h3>Anos de experiencia</h3>
        </div>

        <div class="box">
            <span>100+</span>
            <h3>Projetos concluido</h3>
        </div>

        <div class="box">
            <span>430+</span>
            <h3>Clientes satisfeitos</h3>
        </div>

        <div class="box">
            <span>12+</span>
            <a href="#cursos"><h3>Premios ganho</h3></a>


           
        </div>

    </div>

</div>

</section>

<!-- about section ends -->

<!-- education section starts  -->

<section class="education" id="education">

<h1 class="heading"> Meus <span>cursos e certificações</span> </h1>

<div class="box-container">

    <div class="box">
        <i class="fas fa-graduation-cap"></i>
        <span>2016</span>
        <h3>front end development</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati quos alias praesentium. Id autem provident laborum quae, distinctio eaque temporibus!</p>
    </div>

    <div class="box">
        <i class="fas fa-graduation-cap"></i>
        <span>2017</span>
        <h3>front end development</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati quos alias praesentium. Id autem provident laborum quae, distinctio eaque temporibus!</p>
    </div>

    <div class="box">
        <i class="fas fa-graduation-cap"></i>
        <span>2018</span>
        <h3>front end development</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati quos alias praesentium. Id autem provident laborum quae, distinctio eaque temporibus!</p>
    </div>

    <div class="box">
        <i class="fas fa-graduation-cap"></i>
        <span>2019</span>
        <h3>front end development</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati quos alias praesentium. Id autem provident laborum quae, distinctio eaque temporibus!</p>
    </div>

    <div class="box">
        <i class="fas fa-graduation-cap"></i>
        <span>2020</span>
        <h3>front end development</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati quos alias praesentium. Id autem provident laborum quae, distinctio eaque temporibus!</p>
    </div>

    <div class="box">
        <i class="fas fa-graduation-cap"></i>
        <span>2021</span>
        <h3>front end development</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati quos alias praesentium. Id autem provident laborum quae, distinctio eaque temporibus!</p>
    </div>

</div>

</section>

<!-- education section ends -->

<!-- portfolio section starts  -->

<section class="portfolio" id="portfolio">

<h1 class="heading"> meu <span>portfolio</span> </h1>

<div class="box-container">

    <div class="box">
       <a href="http://www.google.com.br"> <img src="images/carrocel.gif" alt=""></a>
    </div>

    <div class="box">
        <img src="images/botoes.gif" alt="">
    </div>

    <div class="box">
        <img src="images/loading.gif" alt="">
    </div>

    <div class="box">
        <img src="images/img4.jpg" alt="">
    </div>

    <div class="box">
        <a href="webscraping.php"><img src="images/webscraping.jpeg" alt=""></a>
        <h3>legenda de imagens</h3>
    </div>

    <div class="box">
        <img src="images/login.gif" alt="">
    </div>
   

</div>

</section>

<!-- portfolio section ends -->

<!-- contact section starts  -->

<section class="contact" id="contact">

<h1 class="heading"> <span>Entre em</span> contato </h1>

<div class="row">

    <div class="content">

        <h3 class="title">informações de contato</h3>

        <div class="info">
            <h3> <i class="fas fa-envelope"></i> ruysdaelmorais01@gmail.com </h3>
            <h3> <i class="fas fa-phone"></i> +55(97)98413-2747 </h3>
            <h3> <i class="fas fa-phone"></i> +55(97)98413-2747 </h3>
            <h3> <i class="fas fa-map-marker-alt"></i> Apuí-AM, Brasil - 69265-000. </h3>
        </div>

    </div>

    <form action="">

        <input type="text" placeholder="Nome" class="box">
        <input type="email" placeholder="email" class="box">
        <input type="text" placeholder="Projeto" class="box">
        <textarea name="" id="" cols="30" rows="10" class="box message" placeholder="mensagem"></textarea>
        <button type="submit" class="btn"> Enviar <i class="fas fa-paper-plane"></i> </button>

    </form>

</div>

</section>

<!-- contact section ends -->


<!-- scroll top button  -->

<a href="#home" class="top">
    <img src="images/scroll-top-img.pn" alt="">
</a>















<!-- jquery cdn link  -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>


<!-- aqui um script referente ao botao -->
<script>
    const marker = document.querySelector
    ('#marker');
    const item = document.querySelectorAll('ul li a');
    function indicator(e){
        marker.style.left = e.offsetLeft+'px';
        marker.style.width = e.offsetwidth+'px';
    }
    item.forEach(link=>{
        link.addEventListener('mousemove',(e) => {
            indicator(e.target);
        })
    })
</script>


</body>
</html>